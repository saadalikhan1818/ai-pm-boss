'use client'
// components/AIInputBox.tsx
// Main AI command input — accepts natural language and calls agent endpoints

import { useState, useRef, useEffect } from 'react'
import { Send, Loader2, Zap } from 'lucide-react'
import { agentsApi } from '@/lib/api'

interface Props {
  projectId?: number
}

const SUGGESTIONS = [
  'Create tasks for user authentication module',
  'Predict delay risk for sprint 4',
  'Generate weekly report for AI PM Boss Core',
  'Write standup summary for the team',
]

export default function AIInputBox({ projectId = 1 }: Props) {
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [logs, setLogs] = useState<{ text: string; type: 'user' | 'agent' | 'error' }[]>([])
  const [showSuggestions, setShowSuggestions] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)
  const logsEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [logs])

  const detect = (text: string) => {
    const t = text.toLowerCase()
    if (t.includes('task') || t.includes('create') || t.includes('build')) return 'task'
    if (t.includes('delay') || t.includes('risk') || t.includes('predict')) return 'delay'
    if (t.includes('report') || t.includes('weekly') || t.includes('summary')) return 'report'
    if (t.includes('standup') || t.includes('update')) return 'standup'
    return 'task'
  }

  const handleSubmit = async () => {
    if (!input.trim() || loading) return

    const userText = input.trim()
    setInput('')
    setShowSuggestions(false)
    setLogs(l => [...l, { text: `> ${userText}`, type: 'user' }])
    setLoading(true)

    const intent = detect(userText)
    setLogs(l => [...l, { text: `[AI PM Boss] Routing to ${intent} agent...`, type: 'agent' }])

    try {
      let res
      if (intent === 'task')    res = await agentsApi.createTasks(userText, projectId)
      else if (intent === 'delay')   res = await agentsApi.predictDelay(projectId)
      else if (intent === 'report')  res = await agentsApi.generateReport(projectId)
      else                           res = await agentsApi.standup(projectId)

      const message = res.data?.message || res.data?.result || 'Agent completed successfully.'
      setLogs(l => [...l, { text: `✓ ${message}`, type: 'agent' }])
    } catch {
      setLogs(l => [...l, { text: '✗ Backend offline — showing demo mode.', type: 'error' }])
      // Demo fallback
      setTimeout(() => {
        setLogs(l => [...l, {
          text: `✓ [DEMO] ${intent === 'task' ? '5 tasks created from your input.' : intent === 'delay' ? 'Risk: Sprint 3 at 48% — moderate delay risk detected.' : 'Report generated and sent to #pm-channel.'}`,
          type: 'agent',
        }])
      }, 800)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div
      className="rounded-lg overflow-hidden"
      style={{ border: '1px solid rgba(0,229,255,0.25)', background: 'rgba(0,229,255,0.03)' }}
    >
      {/* Header */}
      <div
        className="flex items-center gap-2 px-4 py-2 border-b"
        style={{ borderColor: 'rgba(0,229,255,0.1)', background: 'rgba(0,229,255,0.05)' }}
      >
        <Zap size={13} color="var(--accent)" />
        <span
          className="text-xs font-semibold tracking-widest"
          style={{ color: 'var(--accent)', fontFamily: 'JetBrains Mono, monospace' }}
        >
          AI COMMAND
        </span>
        <span className="ml-auto text-xs" style={{ color: 'var(--text-dim)', fontFamily: 'JetBrains Mono, monospace' }}>
          GPT-4 / Claude
        </span>
      </div>

      {/* Logs */}
      {logs.length > 0 && (
        <div
          className="terminal-log px-4 py-3 max-h-32 overflow-y-auto border-b"
          style={{ borderColor: 'rgba(0,229,255,0.1)', background: '#050708' }}
        >
          {logs.map((l, i) => (
            <div
              key={i}
              className="mb-0.5"
              style={{
                color: l.type === 'user' ? 'var(--accent)' : l.type === 'error' ? 'var(--red)' : 'var(--green)',
              }}
            >
              {l.text}
            </div>
          ))}
          <div ref={logsEndRef} />
        </div>
      )}

      {/* Input row */}
      <div className="flex items-center gap-3 px-4 py-3 relative">
        <span style={{ color: 'var(--accent)', fontFamily: 'JetBrains Mono, monospace', fontSize: 14 }}>$</span>
        <input
          ref={inputRef}
          className="ai-input flex-1"
          placeholder="Describe what to do — AI will handle it..."
          value={input}
          onChange={e => setInput(e.target.value)}
          onFocus={() => setShowSuggestions(true)}
          onBlur={() => setTimeout(() => setShowSuggestions(false), 150)}
          onKeyDown={e => e.key === 'Enter' && handleSubmit()}
        />
        <button
          onClick={handleSubmit}
          disabled={loading || !input.trim()}
          className="flex items-center gap-2 px-3 py-1.5 rounded text-xs font-semibold transition-all"
          style={{
            background: loading || !input.trim() ? 'var(--border)' : 'rgba(0,229,255,0.15)',
            color: loading || !input.trim() ? 'var(--muted)' : 'var(--accent)',
            border: '1px solid',
            borderColor: loading || !input.trim() ? 'var(--border)' : 'rgba(0,229,255,0.3)',
            cursor: loading || !input.trim() ? 'not-allowed' : 'pointer',
            fontFamily: 'JetBrains Mono, monospace',
          }}
        >
          {loading ? <Loader2 size={13} className="animate-spin" /> : <Send size={13} />}
          {loading ? 'Running...' : 'Run'}
        </button>

        {/* Suggestions dropdown */}
        {showSuggestions && !input && (
          <div
            className="absolute left-4 right-4 bottom-full mb-1 rounded-lg overflow-hidden z-10"
            style={{ background: 'var(--surface)', border: '1px solid var(--border)' }}
          >
            {SUGGESTIONS.map((s, i) => (
              <button
                key={i}
                className="w-full text-left px-3 py-2 text-xs transition-colors"
                style={{ color: 'var(--text-dim)', fontFamily: 'JetBrains Mono, monospace' }}
                onMouseDown={() => { setInput(s); inputRef.current?.focus() }}
                onMouseEnter={e => (e.currentTarget.style.background = 'rgba(0,229,255,0.05)')}
                onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
              >
                <span style={{ color: 'rgba(0,229,255,0.4)' }}>› </span>{s}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
