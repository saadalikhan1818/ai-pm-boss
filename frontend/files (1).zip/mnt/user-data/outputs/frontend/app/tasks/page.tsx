'use client'
// app/tasks/page.tsx — Full task list with filters

import { useState } from 'react'
import Sidebar from '@/components/Sidebar'
import { MOCK_TASKS, Task, tasksApi } from '@/lib/api'
import { Plus, Filter, User, Flag, Clock, ChevronDown } from 'lucide-react'

type FilterStatus   = 'all' | Task['status']
type FilterPriority = 'all' | Task['priority']

const STATUS_OPTS:   FilterStatus[]   = ['all', 'todo', 'in_progress', 'done']
const PRIORITY_OPTS: FilterPriority[] = ['all', 'high', 'medium', 'low']

const STATUS_LABELS: Record<string, string> = { todo: 'To Do', in_progress: 'In Progress', done: 'Done', all: 'All' }

export default function TasksPage() {
  const [tasks, setTasks]         = useState<Task[]>(MOCK_TASKS)
  const [statusF, setStatusF]     = useState<FilterStatus>('all')
  const [priorityF, setPriorityF] = useState<FilterPriority>('all')
  const [search, setSearch]       = useState('')
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState({ title: '', description: '', priority: 'medium', project_id: 1 })

  const filtered = tasks.filter(t => {
    if (statusF !== 'all'   && t.status   !== statusF)   return false
    if (priorityF !== 'all' && t.priority !== priorityF) return false
    if (search && !t.title.toLowerCase().includes(search.toLowerCase())) return false
    return true
  })

  const handleCreate = async () => {
    if (!form.title.trim()) return
    try {
      const res = await tasksApi.create(form as Partial<Task>)
      setTasks(p => [...p, res.data])
    } catch {
      setTasks(p => [...p, {
        id: Date.now(), ...form, status: 'todo', assignee_name: undefined,
        created_at: new Date().toISOString(),
      } as Task])
    }
    setForm({ title: '', description: '', priority: 'medium', project_id: 1 })
    setShowModal(false)
  }

  const updateStatus = async (id: number, status: Task['status']) => {
    try { await tasksApi.update(id, { status }) } catch {}
    setTasks(p => p.map(t => t.id === id ? { ...t, status } : t))
  }

  const PRIORITY_COLORS: Record<string, string> = { high: 'var(--red)', medium: 'var(--yellow)', low: 'var(--green)' }

  return (
    <div className="flex min-h-screen grid-bg" style={{ background: 'var(--bg)' }}>
      <Sidebar />
      <main className="ml-56 flex-1 p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-xl font-bold" style={{ fontFamily: 'Syne, sans-serif' }}>Tasks</h1>
            <p className="text-sm mt-0.5" style={{ color: 'var(--text-dim)' }}>{filtered.length} of {tasks.length} tasks</p>
          </div>
          <button
            onClick={() => setShowModal(true)}
            className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold"
            style={{ background: 'rgba(0,229,255,0.12)', color: 'var(--accent)', border: '1px solid rgba(0,229,255,0.25)' }}
          >
            <Plus size={14} /> New Task
          </button>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-3 mb-6 flex-wrap">
          {/* Search */}
          <input
            className="px-3 py-1.5 rounded-lg text-sm outline-none"
            style={{ background: 'var(--surface)', border: '1px solid var(--border)', color: 'var(--text)', minWidth: 200 }}
            placeholder="Search tasks..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />

          {/* Status filter */}
          <div className="flex items-center gap-1">
            {STATUS_OPTS.map(s => (
              <button
                key={s}
                onClick={() => setStatusF(s)}
                className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
                style={{
                  background: statusF === s ? 'rgba(0,229,255,0.12)' : 'var(--surface)',
                  color: statusF === s ? 'var(--accent)' : 'var(--text-dim)',
                  border: `1px solid ${statusF === s ? 'rgba(0,229,255,0.25)' : 'var(--border)'}`,
                  fontFamily: 'JetBrains Mono, monospace',
                }}
              >
                {STATUS_LABELS[s]}
              </button>
            ))}
          </div>

          {/* Priority filter */}
          <div className="flex items-center gap-1 ml-2">
            {PRIORITY_OPTS.map(p => (
              <button
                key={p}
                onClick={() => setPriorityF(p)}
                className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all capitalize"
                style={{
                  background: priorityF === p ? `${PRIORITY_COLORS[p] || 'var(--accent)'}18` : 'var(--surface)',
                  color: priorityF === p ? PRIORITY_COLORS[p] || 'var(--accent)' : 'var(--text-dim)',
                  border: `1px solid ${priorityF === p ? `${PRIORITY_COLORS[p] || 'var(--accent)'}40` : 'var(--border)'}`,
                  fontFamily: 'JetBrains Mono, monospace',
                }}
              >
                {p}
              </button>
            ))}
          </div>
        </div>

        {/* Task table */}
        <div className="card overflow-hidden">
          {/* Table head */}
          <div
            className="grid grid-cols-12 gap-3 px-4 py-2 text-xs border-b"
            style={{ borderColor: 'var(--border)', color: 'var(--text-dim)', fontFamily: 'JetBrains Mono, monospace', letterSpacing: '0.06em' }}
          >
            <span className="col-span-1">#</span>
            <span className="col-span-4">TITLE</span>
            <span className="col-span-2">STATUS</span>
            <span className="col-span-2">PRIORITY</span>
            <span className="col-span-2">ASSIGNEE</span>
            <span className="col-span-1">ACTIONS</span>
          </div>

          {filtered.length === 0 ? (
            <div className="py-16 text-center" style={{ color: 'var(--muted)' }}>
              No tasks match your filters
            </div>
          ) : (
            filtered.map((task, i) => (
              <div
                key={task.id}
                className="grid grid-cols-12 gap-3 px-4 py-3 items-center border-b transition-colors group"
                style={{
                  borderColor: 'var(--border)',
                  background: i % 2 === 0 ? 'transparent' : 'rgba(255,255,255,0.01)',
                  animation: `slideUp 0.3s ease-out ${i * 30}ms forwards`,
                  opacity: 0,
                }}
              >
                <span className="col-span-1 text-xs" style={{ color: 'var(--muted)', fontFamily: 'JetBrains Mono, monospace' }}>
                  #{task.id.toString().padStart(3, '0')}
                </span>
                <span className="col-span-4 text-sm font-medium" style={{ color: 'var(--text)' }}>
                  {task.title}
                </span>
                <span className="col-span-2">
                  <span className={`badge badge-${task.status}`}>
                    {STATUS_LABELS[task.status]}
                  </span>
                </span>
                <span className="col-span-2">
                  <span className={`badge badge-${task.priority}`}>
                    <Flag size={8} />
                    {task.priority}
                  </span>
                </span>
                <span className="col-span-2 text-xs flex items-center gap-1.5" style={{ color: 'var(--text-dim)' }}>
                  {task.assignee_name ? (
                    <>
                      <div
                        className="w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0"
                        style={{ background: 'rgba(0,229,255,0.15)', color: 'var(--accent)' }}
                      >
                        {task.assignee_name.charAt(0)}
                      </div>
                      {task.assignee_name}
                    </>
                  ) : (
                    <><User size={11} /> Unassigned</>
                  )}
                </span>
                <span className="col-span-1">
                  <select
                    className="text-xs rounded px-1 py-0.5 outline-none cursor-pointer"
                    style={{ background: 'var(--bg)', border: '1px solid var(--border)', color: 'var(--text-dim)' }}
                    value={task.status}
                    onChange={e => updateStatus(task.id, e.target.value as Task['status'])}
                  >
                    <option value="todo">To Do</option>
                    <option value="in_progress">In Progress</option>
                    <option value="done">Done</option>
                  </select>
                </span>
              </div>
            ))
          )}
        </div>
      </main>

      {/* Create task modal */}
      {showModal && (
        <div
          className="fixed inset-0 flex items-center justify-center z-50"
          style={{ background: 'rgba(8,11,16,0.85)' }}
          onClick={e => e.target === e.currentTarget && setShowModal(false)}
        >
          <div className="w-96 rounded-xl p-6" style={{ background: 'var(--surface)', border: '1px solid rgba(0,229,255,0.2)' }}>
            <h2 className="text-base font-bold mb-4" style={{ fontFamily: 'Syne, sans-serif', color: 'var(--accent)' }}>
              New Task
            </h2>
            <div className="space-y-3">
              <div>
                <label className="text-xs mb-1 block" style={{ color: 'var(--text-dim)' }}>Title</label>
                <input
                  className="w-full px-3 py-2 rounded-lg text-sm outline-none"
                  style={{ background: 'var(--bg)', border: '1px solid var(--border)', color: 'var(--text)' }}
                  value={form.title}
                  onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
                />
              </div>
              <div>
                <label className="text-xs mb-1 block" style={{ color: 'var(--text-dim)' }}>Priority</label>
                <select
                  className="w-full px-3 py-2 rounded-lg text-sm outline-none"
                  style={{ background: 'var(--bg)', border: '1px solid var(--border)', color: 'var(--text)' }}
                  value={form.priority}
                  onChange={e => setForm(f => ({ ...f, priority: e.target.value }))}
                >
                  <option value="high">High</option>
                  <option value="medium">Medium</option>
                  <option value="low">Low</option>
                </select>
              </div>
              <div className="flex gap-2 pt-1">
                <button onClick={() => setShowModal(false)} className="flex-1 py-2 rounded-lg text-sm" style={{ background: 'var(--bg)', border: '1px solid var(--border)', color: 'var(--text-dim)' }}>
                  Cancel
                </button>
                <button onClick={handleCreate} className="flex-1 py-2 rounded-lg text-sm font-semibold" style={{ background: 'rgba(0,229,255,0.15)', color: 'var(--accent)', border: '1px solid rgba(0,229,255,0.25)' }}>
                  Create Task
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
